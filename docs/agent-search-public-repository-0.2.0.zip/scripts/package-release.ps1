[CmdletBinding()]
param([string]$OutputDirectory = './dist')

# Maintainer-only packaging. Never runs as a plugin hook.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$releaseRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$releaseOutput = [IO.Path]::GetFullPath($OutputDirectory)
$releaseVersion = '0.2.0'
$releaseStamp = [DateTimeOffset]::new(2026, 9, 16, 0, 0, 0, [TimeSpan]::Zero)
New-Item -ItemType Directory -Path $releaseOutput -Force | Out-Null

function Get-ReleaseFiles([string[]]$Selections) {
    $selected = [Collections.Generic.List[object]]::new()
    foreach ($selection in $Selections) {
        $full = [IO.Path]::GetFullPath((Join-Path $releaseRoot $selection))
        if (-not $full.StartsWith($releaseRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw "Outside release root: $selection" }
        $item = Get-Item -LiteralPath $full -Force
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Links are not allowed: $selection" }
        $children = if ($item.PSIsContainer) { @(Get-ChildItem -LiteralPath $full -Recurse -Force) } else { @($item) }
        foreach ($child in $children) {
            if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Links are not allowed: $($child.FullName)" }
            if ($child.PSIsContainer) { continue }
            $relative = [IO.Path]::GetRelativePath($releaseRoot, $child.FullName).Replace('\', '/')
            if ($relative -match '(^|/)(\.git|node_modules|\.env[^/]*)(/|$)' -or $relative -match '\.(pem|key|pfx|db|sqlite|bak)$') { throw "Forbidden release path: $relative" }
            if ($child.Extension -notin @('.md', '.json', '.toml', '.png', '.ps1') -and $child.Name -notin @('LICENSE', '.gitignore')) { throw "Unapproved release file: $relative" }
            if ($child.Extension -ne '.png') {
                $content = [IO.File]::ReadAllText($child.FullName)
                $secretPattern = '(?:amak|amat|amct)_[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN [A-Z ]*PRIVATE KEY-----'
                if ($content -match $secretPattern) { throw "Possible credential in: $relative" }
                if ($child.Extension -eq '.json') { $null = $content | ConvertFrom-Json }
            }
            $selected.Add([pscustomobject]@{ Source = $child.FullName; Entry = $relative })
        }
    }
    return @($selected | Sort-Object Entry -Unique)
}

function Write-ReleaseZip([string]$Name, [object[]]$Files) {
    $destination = Join-Path $releaseOutput $Name
    if (Test-Path -LiteralPath $destination) { throw "Refusing to replace existing archive: $destination" }
    $archive = [IO.Compression.ZipFile]::Open($destination, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in ($Files | Sort-Object Entry)) {
            if ($file.Entry -match '(^/|(^|/)\.\.(/|$)|\\)') { throw "Unsafe ZIP path: $($file.Entry)" }
            $entry = $archive.CreateEntry($file.Entry, [IO.Compression.CompressionLevel]::Optimal)
            $entry.LastWriteTime = $releaseStamp
            $inputStream = [IO.File]::OpenRead($file.Source)
            $outputStream = $entry.Open()
            try { $inputStream.CopyTo($outputStream) } finally { $outputStream.Dispose(); $inputStream.Dispose() }
        }
    } finally { $archive.Dispose() }
    # Round-trip every entry: archive content must match the exact selected source bytes.
    $reopened = [IO.Compression.ZipFile]::OpenRead($destination)
    try {
        if ($reopened.Entries.Count -ne $Files.Count) { throw "ZIP entry count mismatch: $Name" }
        foreach ($file in $Files) {
            $entry = $reopened.GetEntry($file.Entry)
            if ($null -eq $entry) { throw "Missing ZIP entry: $($file.Entry)" }
            $stream = $entry.Open()
            try { $actual = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) } finally { $stream.Dispose() }
            $expected = (Get-FileHash -LiteralPath $file.Source -Algorithm SHA256).Hash
            if ($actual -ne $expected) { throw "ZIP content mismatch: $($file.Entry)" }
        }
    } finally { $reopened.Dispose() }
    Write-Host "Verified $Name ($($Files.Count) entries)"
    return [pscustomobject]@{ Source = $destination; Entry = $Name }
}

$commonFiles = @(Get-ReleaseFiles @('docs', 'examples', 'LICENSE', 'SECURITY.md', 'CHANGELOG.md', 'submission/README.zh-CN.md', 'submission/reviewer-tests.md', 'submission/verification.md') | ForEach-Object {
    $entryName = $_.Entry -replace '^submission/', ''
    if ($entryName -eq 'README.zh-CN.md') { $entryName = 'READ_FIRST.zh-CN.md' }
    [pscustomobject]@{ Source = $_.Source; Entry = $entryName }
})
$archives = [Collections.Generic.List[object]]::new()
foreach ($platform in @('openai', 'claude')) {
    $pluginPrefix = "plugins/$platform/agent-search/"
    $pluginFiles = @(Get-ReleaseFiles @("plugins/$platform/agent-search") | ForEach-Object {
        [pscustomobject]@{ Source = $_.Source; Entry = $_.Entry.Substring($pluginPrefix.Length) }
    })
    $pluginZip = Write-ReleaseZip "agent-search-$platform-plugin-$releaseVersion.zip" $pluginFiles
    $archives.Add($pluginZip)
    $platformFiles = @(Get-ReleaseFiles @("submission/$platform") | ForEach-Object {
        [pscustomobject]@{ Source = $_.Source; Entry = $_.Entry.Substring("submission/$platform/".Length) }
    })
    $kitFiles = @($commonFiles) + @($platformFiles) + @($pluginZip) + @([pscustomobject]@{ Source = Join-Path $releaseRoot "$pluginPrefix/assets/logo.png"; Entry = 'logo.png' })
    if ($platform -eq 'claude') {
        $kitFiles += [pscustomobject]@{ Source = Join-Path $releaseRoot '.claude-plugin/marketplace.json'; Entry = 'marketplace.reference.json' }
    }
    $archives.Add((Write-ReleaseZip "agent-search-$platform-submission-$releaseVersion.zip" $kitFiles))
}
$publicSource = @(Get-ReleaseFiles @('README.md', 'SECURITY.md', 'LICENSE', 'CHANGELOG.md', 'skill.md', 'mcp-config.example.json', '.gitignore', '.claude-plugin', 'docs', 'examples', 'plugins', 'submission', 'scripts'))
$archives.Add((Write-ReleaseZip "agent-search-public-repository-$releaseVersion.zip" $publicSource))
$checksums = @($archives | ForEach-Object { "{0}  {1}" -f (Get-FileHash -LiteralPath $_.Source -Algorithm SHA256).Hash.ToLowerInvariant(), $_.Entry })
[IO.File]::WriteAllLines((Join-Path $releaseOutput 'SHA256SUMS.txt'), $checksums, [Text.UTF8Encoding]::new($false))
Copy-Item -LiteralPath (Join-Path $releaseRoot 'submission/README.zh-CN.md') -Destination (Join-Path $releaseOutput 'READ_FIRST.zh-CN.md')
Write-Host "Release artifacts: $releaseOutput"
