# Claude: two different submission paths / 两种提交路径

listing.worksheet.json 是人工填写工作表，不是可直接导入的官方表单。ZIP 没有经过 Anthropic 审核。

## A. Claude remote MCP Connectors Directory

This is the relevant route for the hosted endpoint `https://tatanexus.com/api/mcp`. Follow the [official submission page](https://claude.com/docs/connectors/building/submission) to enter the current portal.

As checked on 2026-09-16, the remote-server portal requires a Team/Enterprise organization and directory management access. An individual developer identity does not by itself supply organization access.

Prepare the endpoint, listing text, logo, documentation/privacy URLs, a monitored support and review contact, and a populated isolated test account. The live service still needs authentication and tool-metadata work described in verification.md. Manual API-key support in Claude Code does not establish supported Claude cloud account linking. Do not confirm that every tool was tested until those tests have actually run.

The service includes sponsored content and separate authorized financial tools: disclose both and review applicable directory policies. A plugin ZIP is not a remote-directory application and is not an MCPB.

## B. Claude Code community plugin marketplace

Individual authors can use the [Console plugin form](https://platform.claude.com/plugins/submit). See [official plugin distribution guidance](https://code.claude.com/docs/en/plugins#submit-your-plugin-to-the-community-marketplace).

Repository: `https://github.com/Lingxing-Kong/agent-search-mcp`

Plugin directory: `plugins/claude/agent-search`

Manifest: `plugins/claude/agent-search/.claude-plugin/plugin.json`

Use `agent-search-claude-plugin-0.2.0.zip` as the self-contained plugin payload where requested; provide repository and exact commit if the form requests them. This is not an application to Anthropic's separately curated official marketplace.

For direct GitHub distribution, the repository already includes a publisher marketplace:

```text
/plugin marketplace add Lingxing-Kong/agent-search-mcp
/plugin install agent-search@tatanexus
```

Local validation:

```text
claude plugin validate plugins/claude/agent-search
claude plugin validate .
```

## Material checklist

- listing.worksheet.json: public listing draft; null values must be supplied by the publisher.
- logo.png: existing product branding.
- reviewer-tests.md: scenarios, not claimed test results.
- verification.md: actual verification and remaining work.
- docs/: bilingual public usage documentation.
- plugin ZIP: Claude Code only; it is not a local-server Desktop Extension.
