# 提交包使用说明

版本：0.2.0；材料核对日期：2026-09-16。

## 先区分三个入口

| 目标 | 本仓库材料 | 如何使用 |
| --- | --- | --- |
| OpenAI / Codex MCP 插件 | plugins/openai/agent-search + submission/openai | 解压提交材料包；插件 ZIP、Logo 与文案分开使用。远程 MCP 审核还会连接真实 endpoint。 |
| Claude 远程 MCP Connectors Directory | submission/claude | 在官方远程连接器门户填写 endpoint、文案、隐私政策、认证和审核账户；不是上传 Claude Code ZIP 就能上架。 |
| Claude Code 插件 | plugins/claude/agent-search + .claude-plugin/marketplace.json | 可从 GitHub 安装；另可向 Claude Code 社区插件市场提交仓库及插件目录。 |

## 当前状态：材料已准备，尚不满足完整认证版正式上架

- 已有稳定 HTTPS MCP 地址、官网、公开功能文档、隐私政策/条款地址和原有品牌 Logo。
- 已核验匿名初始化、工具发现、公开需求读取、未认证拒绝和无效参数拒绝。
- 认证写入、每个工具的完整端到端审核用例尚未在本次发布中执行；没有使用真实账户发帖或付款。
- 当前是手动 Bearer 凭证；标准 OAuth 发现地址本次返回 404。不能把 API key 配置声称为 OAuth 登录。
- 匿名目录的 6 个基础工具缺少 annotations，全部 15 个工具没有 title/annotations.title；必须在服务器补齐后重新扫描。认证目录也需要完整复核。
- 需由发布者填写审核联系邮箱、确认开发者/域名身份、支持地区、提供隔离测试账户；不在公开 ZIP 中放凭证。
- Claude 远程目录当前要求 Team/Enterprise 组织及目录管理权限。个人身份与个人套餐是不同问题；Claude Code 社区插件提交入口另行列出。
- 同一 endpoint 可向有权限的账户提供广告/credits/USDC 工具。提交时必须如实披露，不得宣称整个连接仅只读或完全无交易功能。是否符合目标平台政策由实际工具范围与审核决定。

详细核验见 [verification.md](verification.md)，人工审核步骤见 [reviewer-tests.md](reviewer-tests.md)。

## 不包含什么

不包含私有后端源码、生产环境配置、数据库、钱包/云凭证、真实 Agent key、私有 Git 历史、虚构审核记录或不存在的 UI 截图。纯 MCP 插件没有内嵌交互 UI，因此没有伪造 MCP App 截图。不要把这些 ZIP 改名为 MCPB；我们连接的是已托管的远程服务。

先解决明确的服务端缺口，再提交完整认证版；也可单独规划只读版，但本次没有改动或裁剪生产 endpoint。
