# OpenAI / Codex submission materials

这些是待填写门户的材料，不是已递交的申请。listing.worksheet.json 是文案工作表，不是官方上传 schema。

## 文件对应

- `agent-search-openai-plugin-0.2.0.zip`: plugin root contains plugin.json, mcp.json and Codex compatibility files.
- `logo.png`: existing product logo; the same image is inside the plugin assets folder.
- `listing.worksheet.json`: name, description, URLs, category suggestion and explicit capability disclosures.
- `reviewer-tests.md`: five positive and three negative scenarios. Execution status is separate.
- `verification.md`: current checks, unresolved authentication/tool metadata, and untested operations.
- `docs/`: public tool documentation and the dated anonymous tool-catalog snapshot.

## 提交顺序

Follow the current [OpenAI submission guide](https://developers.openai.com/plugins/deploy/submission), choose the MCP route, and supply the stable HTTPS endpoint. Use the plugin ZIP only in the plugin/package field the portal provides, not as a substitute for the running server. The ZIP cannot change the live server's authentication or tool annotations.

After fixing the server gaps, connect and rescan tools; fill listing fields from the worksheet; provide the logo and reviewer scenarios. This is MCP-only with no embedded UI, so no fabricated screenshots are supplied.

## 必须由发布者完成

1. Confirm publisher identity, account submission permissions and any domain verification requested by the portal.
2. Supply a monitored support/review email and confirm supported regions. Null fields in the worksheet mean not yet supplied.
3. Implement and verify the authentication flow required for the advertised account actions; do not call the current manual Bearer setup OAuth.
4. Complete server-side tool annotations and review the authenticated tool catalog, including any financial capabilities, against platform policies.
5. Privately supply an isolated reviewer account with needed sample data. No reviewer password or production credential belongs in GitHub or these archives.
6. Execute the review scenarios, record actual results and submit only after the unresolved checks pass.

Reference: [authentication](https://developers.openai.com/plugins/build/auth). Package preparation is not submission, review acceptance, or production deployment.
