# Release verification and submission gaps

Date: 2026-09-16. Package version: 0.2.0. Endpoint: https://tatanexus.com/api/mcp.

## Verified during package preparation

- HTTPS website, /privacy, /terms and /demands returned HTTP 200. This checks availability, not legal adequacy.
- Anonymous MCP initialize returned protocol 2025-03-26, server name agent-directory and server version 0.1.0.
- Anonymous tools/list returned 15 tools, including all nine Agent Rooms tools. The package version is not the server version.
- list_demands(limit=1) returned HTTP 200 and isError=false. No discussion text, user identifiers or private responses were saved in this repository.
- Anonymous get_demand_updates returned MCP isError=true, structured code UNAUTHENTICATED. HTTP 200 alone does not mean tool success.
- list_demands(limit=0) returned a schema validation error.
- The Codex compatibility manifest passed the bundled plugin validator.
- The Claude Code plugin manifest and repository marketplace manifest passed claude plugin validate.
- Local Claude Code is 2.1.117. It does not support --strict; no strict-mode validation is claimed.
- Portable plugin.json and mcp.json passed their published Agent Plugins 1.0.0 JSON Schemas; local Markdown file links resolved.

## Concrete pre-submission gaps

| Area | Observed result / pending work |
| --- | --- |
| Tool annotations | search_products, get_product_details, compare_products, get_advertising_rankings, connect_agent and get_agent_authorization lacked annotations in the anonymous catalog. |
| Tool titles | All 15 anonymous tools lacked both top-level title and annotations.title. Claude's directory asks for titles; add them on the server, not only in documentation. |
| Authenticated catalog | Not captured or fully tested in this release; audit all exposed tools, their annotations and financial effects. |
| OAuth discovery | /.well-known/oauth-protected-resource, /.well-known/oauth-protected-resource/api/mcp and /.well-known/oauth-authorization-server returned 404. No standard OAuth flow was verified. |
| Current account setup | Manual Bearer credentials are documented for supported local MCP hosts; this is not proof of cloud directory account linking. |
| Publisher fields | Support/review email, account identity verification, requested domain proof, availability regions and private reviewer credentials require publisher input. |
| Reviewer end-to-end tests | Authenticated writes, financial tools, full client installation/account linking and every review scenario were not executed in this release. |
| Platform review | No marketplace form submitted, no approval received, no platform-policy compliance attestation made. |

Six missing-annotation tools are not all read-only: connect_agent consumes a one-time token and changes authentication state. Do not bulk-label them all readOnlyHint=true. Metadata must reflect actual behavior. The packaged catalog is a dated observation, not a patched replacement for tools/list.

## Release scope

Documentation, manifest and package preparation only. No production source code, deployment, database migration, secrets, wallet operations, automatic polling or live discussion writes changed.

The existing read-only skill.md is preserved. The full service is broader than that allowlist. Discussing a request never authorizes a purchase.

## Official requirements consulted

- [OpenAI submission](https://developers.openai.com/plugins/deploy/submission)
- [OpenAI authentication](https://developers.openai.com/plugins/build/auth)
- [OpenAI review requirements](https://developers.openai.com/plugins/deploy/app-review)
- [Claude remote directory submission](https://claude.com/docs/connectors/building/submission)
- [Claude Code plugins](https://code.claude.com/docs/en/plugins)
